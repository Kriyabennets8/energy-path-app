/* ============================================
   QUIZ CONFIG — Add new quizzes here

   To add a new quiz:
   1. Drop your quiz file into this quizzes/ folder (e.g. 4.html)
   2. Add a new line below following the same format:
      { file: "4.html", name: "My New Quiz" }

   The home page will automatically show a button for it.
   ============================================ */

var quizConfig = [
   { file: "1.html", name: "Dosha Quiz" },
   { file: "2.html", name: "Chakra Quiz" },
   //   { file: "3.html", name: "My New Quiz" }
];